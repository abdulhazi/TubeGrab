package com.steven.tubegrab

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Keeps downloads running (with a progress notification) while you use other apps. */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var lastNotify = 0L
    private var stopped = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW)
        )
        ServiceCompat.startForeground(
            this, ID, build(Downloader.state.value), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        scope.launch {
            Downloader.state.collect { s ->
                if (stopped) return@collect
                if (!s.busy && s.queued == 0) {
                    stopped = true
                    ServiceCompat.stopForeground(this@DownloadService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                    nm.notify(
                        DONE_ID,
                        NotificationCompat.Builder(this@DownloadService, CHANNEL)
                            .setSmallIcon(android.R.drawable.stat_sys_download_done)
                            .setContentTitle("TubeGrab")
                            .setContentText(s.status)
                            .setStyle(NotificationCompat.BigTextStyle().bigText(s.status))
                            .setContentIntent(openApp())
                            .setAutoCancel(true)
                            .build()
                    )
                    stopSelf()
                } else {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastNotify > 700) {
                        lastNotify = now
                        nm.notify(ID, build(s))
                    }
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun build(s: DlState): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(s.current?.let { "Downloading from ${it.label}" } ?: "TubeGrab")
            .setContentText(s.status + if (s.queued > 0) " · ${s.queued} queued" else "")
            .setProgress(100, s.progress.coerceAtLeast(0), s.progress < 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp())
            .build()

    companion object {
        private const val CHANNEL = "downloads"
        private const val ID = 1
        private const val DONE_ID = 2

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
            } catch (e: Exception) {
                // Download still runs; only the background notification is missing.
            }
        }
    }
}
