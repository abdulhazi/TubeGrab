package com.steven.tubegrab

import android.app.Application
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        History.init(this)
        Downloader.init(this)
        try {
            YoutubeDL.getInstance().init(this)
            FFmpeg.getInstance().init(this)
            initOk = true
        } catch (e: Exception) {
            initError = e.message
            Log.e("TubeGrab", "Failed to initialise yt-dlp", e)
        }
    }

    companion object {
        @Volatile var initOk = false
        @Volatile var initError: String? = null
    }
}
