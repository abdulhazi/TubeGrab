package com.steven.tubegrab

import android.Manifest
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.steven.tubegrab.databinding.ActivityMainBinding
import com.steven.tubegrab.databinding.ItemHistoryBinding
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var updating = false

    private val videoQualities = listOf("Best" to 0, "1080p" to 1080, "720p" to 720, "480p" to 480, "360p" to 360)
    private val audioQualities = listOf("320 kbps" to 320, "192 kbps" to 192, "128 kbps" to 128)

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        handleShare(intent)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        b.modeGroup.setOnCheckedChangeListener { _, _ -> refreshQualityOptions() }
        refreshQualityOptions()

        b.pasteButton.setOnClickListener {
            val clip = getSystemService(ClipboardManager::class.java).primaryClip
            val text = clip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!text.isNullOrBlank()) b.urlInput.setText(extractUrl(text) ?: text)
        }

        b.downloadButton.setOnClickListener {
            val raw = b.urlInput.text?.toString().orEmpty()
            val url = extractUrl(raw) ?: raw.trim().takeIf { it.contains('.') }?.let { "https://$it" }
            if (url == null) {
                b.urlLayout.error = "Paste a link first"
                return@setOnClickListener
            }
            b.urlLayout.error = null
            val mode = if (b.modeMp3.isChecked) Mode.MP3 else Mode.MP4
            val list = if (mode == Mode.MP4) videoQualities else audioQualities
            val quality = list.getOrNull(b.qualitySpinner.selectedItemPosition)?.second ?: 0
            val wasBusy = Downloader.state.value.busy
            Downloader.enqueue(this, DownloadJob(url, mode, quality))
            b.urlInput.setText("")
            if (wasBusy) toast("Added to queue")
        }

        b.cancelButton.setOnClickListener { Downloader.cancelCurrent() }
        b.cancelAllButton.setOnClickListener { Downloader.cancelAll() }

        b.browserButton.setOnClickListener {
            val typed = extractUrl(b.urlInput.text?.toString().orEmpty())
            startActivity(Intent(this, BrowserActivity::class.java).apply {
                if (typed != null) putExtra(BrowserActivity.EXTRA_URL, typed)
            })
        }
        b.signInButton.setOnClickListener { showSignInDialog() }
        b.updateButton.setOnClickListener { updateEngine() }
        b.clearHistoryButton.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setMessage("Clear the download history? Your downloaded files stay in Downloads/TubeGrab.")
                .setPositiveButton("Clear") { _, _ -> History.clear() }
                .setNegativeButton("Cancel", null)
                .show()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { Downloader.state.collect { render(it) } }
                launch { History.items.collect { renderHistory(it) } }
            }
        }

        lifecycleScope.launch {
            val v = withContext(Dispatchers.IO) {
                try { YoutubeDL.getInstance().version(applicationContext) } catch (e: Exception) { null }
            }
            if (!updating && v != null) b.engineStatus.text = "Engine: yt-dlp $v"
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun render(s: DlState) {
        b.statusText.text = s.status
        b.progressBar.visibility = if (s.busy) View.VISIBLE else View.GONE
        b.progressBar.isIndeterminate = s.progress < 0
        if (s.progress >= 0) b.progressBar.progress = s.progress
        b.downloadButton.text = if (s.busy) "Add to queue" else "Download"
        b.cancelButton.visibility = if (s.busy) View.VISIBLE else View.GONE
        b.cancelAllButton.visibility = if (s.queued > 0) View.VISIBLE else View.GONE
        b.queueText.visibility = if (s.queued > 0) View.VISIBLE else View.GONE
        b.queueText.text = "${s.queued} more in queue"
        b.updateButton.isEnabled = !s.busy && !updating
    }

    private fun renderHistory(items: List<HistoryEntry>) {
        b.historyList.removeAllViews()
        b.historyEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        b.clearHistoryButton.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())
        for (e in items) {
            val row = ItemHistoryBinding.inflate(layoutInflater, b.historyList, false)
            row.badge.text = Sites.badge(e.host)
            row.badge.backgroundTintList = ColorStateList.valueOf(Sites.color(e.host))
            row.name.text = e.name
            row.meta.text = "${Sites.label(e.host)} · ${e.mode} · ${fmt.format(Date(e.time))}"
            row.root.setOnClickListener { openFile(e) }
            row.root.setOnLongClickListener { shareFile(e); true }
            b.historyList.addView(row.root)
        }
    }

    private fun openFile(e: HistoryEntry) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Uri.parse(e.uri), e.mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (ex: Exception) {
            toast("Can't open it — the file may have been moved or deleted.")
        }
    }

    private fun shareFile(e: HistoryEntry) {
        try {
            val send = Intent(Intent.ACTION_SEND)
                .setType(e.mime)
                .putExtra(Intent.EXTRA_STREAM, Uri.parse(e.uri))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Share"))
        } catch (ex: Exception) {
            toast("Can't share this file.")
        }
    }

    private fun showSignInDialog() {
        val sites = Sites.known.filter { it.loginUrl != null }
        val labels = sites.map { s -> if (Cookies.isSignedIn(s)) "${s.name}   ✓ signed in" else s.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Sign in for private / login-only videos")
            .setItems(labels) { _, i ->
                startActivity(
                    Intent(this, BrowserActivity::class.java)
                        .putExtra(BrowserActivity.EXTRA_URL, sites[i].loginUrl)
                        .putExtra(BrowserActivity.EXTRA_SIGNIN, sites[i].name)
                )
            }
            .setNeutralButton("Sign out of all") { _, _ ->
                Cookies.signOutAll { runOnUiThread { toast("Signed out of all sites") } }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun updateEngine() {
        updating = true
        b.updateButton.isEnabled = false
        b.engineStatus.text = "Updating yt-dlp…"
        lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) {
                try {
                    val r = YoutubeDL.getInstance().updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE)
                    val v = YoutubeDL.getInstance().version(applicationContext) ?: "?"
                    if (r == YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE) "Engine already up to date (yt-dlp $v)."
                    else "Engine updated to yt-dlp $v ✔"
                } catch (e: Exception) {
                    "Update failed: ${e.message?.take(200)}"
                }
            }
            updating = false
            b.engineStatus.text = msg
            b.updateButton.isEnabled = !Downloader.state.value.busy
        }
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            b.urlInput.setText(extractUrl(text) ?: text)
        }
    }

    private fun extractUrl(text: String): String? = Regex("""https?://\S+""").find(text)?.value

    private fun refreshQualityOptions() {
        val list = if (b.modeMp3.isChecked) audioQualities else videoQualities
        b.qualitySpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, list.map { it.first }
        )
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
