package com.steven.tubegrab

import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.steven.tubegrab.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: DownloadViewModel by viewModels()

    private val videoQualities = listOf("Best" to 0, "1080p" to 1080, "720p" to 720, "480p" to 480, "360p" to 360)
    private val audioQualities = listOf("320 kbps" to 320, "192 kbps" to 192, "128 kbps" to 128)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        handleShare(intent)

        b.modeGroup.setOnCheckedChangeListener { _, _ -> refreshQualityOptions() }
        refreshQualityOptions()

        b.pasteButton.setOnClickListener {
            val clip = getSystemService(ClipboardManager::class.java).primaryClip
            val text = clip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!text.isNullOrBlank()) b.urlInput.setText(extractUrl(text) ?: text)
        }

        b.downloadButton.setOnClickListener {
            val url = b.urlInput.text?.toString().orEmpty()
            if (url.isBlank()) {
                b.urlLayout.error = "Paste a link first"
                return@setOnClickListener
            }
            b.urlLayout.error = null
            val mode = if (b.modeMp3.isChecked) Mode.MP3 else Mode.MP4
            val list = if (mode == Mode.MP4) videoQualities else audioQualities
            val quality = list.getOrNull(b.qualitySpinner.selectedItemPosition)?.second ?: 0
            vm.download(url, mode, quality)
        }

        b.cancelButton.setOnClickListener { vm.cancel() }
        b.updateButton.setOnClickListener { vm.updateEngine() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { s ->
                    b.statusText.text = s.status
                    b.progressBar.visibility = if (s.busy) View.VISIBLE else View.INVISIBLE
                    b.progressBar.isIndeterminate = s.progress < 0
                    if (s.progress >= 0) b.progressBar.setProgressCompat(s.progress, true)
                    b.downloadButton.isEnabled = !s.busy
                    b.updateButton.isEnabled = !s.busy
                    b.cancelButton.visibility = if (s.busy) View.VISIBLE else View.GONE
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            b.urlInput.setText(extractUrl(text) ?: text)
        }
    }

    private fun extractUrl(text: String): String? =
        Regex("""https?://\S+""").find(text)?.value

    private fun refreshQualityOptions() {
        val list = if (b.modeMp3.isChecked) audioQualities else videoQualities
        b.qualitySpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, list.map { it.first }
        )
    }
}
