package com.steven.tubegrab

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Mode { MP4, MP3 }

/**
 * @param url      page link (smart mode) or a direct media/stream link found by the browser
 * @param quality  max video height for MP4 (0 = best) or kbps for MP3
 * @param referer  page the media was found on (only for direct media links)
 */
data class DownloadJob(
    val url: String,
    val mode: Mode,
    val quality: Int,
    val referer: String? = null,
    val cookieHosts: List<String> = emptyList(),
) {
    val label: String get() = Sites.label(Sites.host(referer ?: url))
}

data class DlState(
    val current: DownloadJob? = null,
    val progress: Int = -1,
    val status: String = "Paste or share a link to start.",
    val queued: Int = 0,
) {
    val busy: Boolean get() = current != null
}

/** One download at a time; extra jobs wait in a queue. Lives as long as the app process. */
object Downloader {
    private lateinit var app: Application
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val channel = Channel<DownloadJob>(Channel.UNLIMITED)
    private val _state = MutableStateFlow(DlState())
    val state: StateFlow<DlState> = _state.asStateFlow()

    private const val PID = "tubegrab-dl"
    @Volatile private var cancelRequested = false
    @Volatile var browserUserAgent: String? = null

    fun init(a: Application) {
        app = a
        scope.launch {
            for (job in channel) {
                _state.update {
                    it.copy(current = job, progress = -1, status = "Starting…", queued = (it.queued - 1).coerceAtLeast(0))
                }
                runJob(job)
                _state.update { it.copy(current = null, progress = -1) }
            }
        }
    }

    fun enqueue(ctx: Context, job: DownloadJob) {
        _state.update { it.copy(queued = it.queued + 1, status = if (it.busy) it.status else "Queued…") }
        channel.trySend(job)
        DownloadService.start(ctx)
    }

    fun cancelCurrent() {
        cancelRequested = true
        YoutubeDL.getInstance().destroyProcessById(PID)
    }

    fun cancelAll() {
        while (channel.tryReceive().isSuccess) { /* drain */ }
        _state.update { it.copy(queued = 0) }
        cancelCurrent()
    }

    private fun setStatus(s: String, p: Int = -1) = _state.update { it.copy(status = s, progress = p) }

    private suspend fun runJob(job: DownloadJob) {
        cancelRequested = false
        if (!App.initOk) {
            setStatus("Engine failed to start: ${App.initError}")
            return
        }
        val workDir = File(app.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
        try {
            val cookieFile = withContext(Dispatchers.Main) {
                Cookies.export(File(app.filesDir, "cookies.txt"), job.cookieHosts + Sites.host(job.url))
            }

            val request = YoutubeDLRequest(job.url).apply {
                addOption("--no-playlist")
                addOption("--no-mtime")
                addOption("-o", "${workDir.absolutePath}/%(title).80B [%(id).20B].%(ext)s")
                if (cookieFile != null) addOption("--cookies", cookieFile.absolutePath)
                if (job.referer != null) {
                    addOption("--add-header", "Referer:${job.referer}")
                    browserUserAgent?.let { ua -> addOption("--add-header", "User-Agent:$ua") }
                }
                when (job.mode) {
                    Mode.MP4 -> {
                        val h = if (job.quality > 0) "[height<=?${job.quality}]" else ""
                        addOption("-f", "bv*$h[ext=mp4]+ba[ext=m4a]/b$h[ext=mp4]/bv*$h+ba/b$h/b*")
                        addOption("--merge-output-format", "mp4")
                        addOption("--remux-video", "mp4")
                    }
                    Mode.MP3 -> {
                        addOption("-f", "ba/b")
                        addOption("-x")
                        addOption("--audio-format", "mp3")
                        addOption("--audio-quality", if (job.quality > 0) "${job.quality}K" else "0")
                    }
                }
            }

            YoutubeDL.getInstance().execute(request, PID) { progress, eta, _ ->
                val pct = progress.toInt()
                _state.update {
                    it.copy(
                        progress = if (pct in 0..99) pct else -1,
                        status = when {
                            pct >= 100 -> "Processing…"
                            pct >= 0 -> "Downloading… $pct%" + (if (eta > 0) " · ${eta}s left" else "")
                            else -> "Working…"
                        }
                    )
                }
            }

            setStatus("Saving to Downloads…")
            val skip = setOf("part", "ytdl", "txt", "json", "temp", "tmp", "jpg", "jpeg", "webp", "png")
            var files = workDir.listFiles()
                ?.filter { it.isFile && it.extension.lowercase() !in skip && it.length() > 0 }
                .orEmpty()
            if (job.mode == Mode.MP3) {
                val mp3s = files.filter { it.extension.equals("mp3", true) }
                if (mp3s.isNotEmpty()) files = mp3s
            }
            if (files.isEmpty()) error("Finished, but no file was produced.")

            val host = Sites.host(job.referer ?: job.url)
            for (f in files) {
                val (uri, mime) = saveToDownloads(f, job.mode)
                History.add(HistoryEntry(f.name, host, job.mode.name, uri.toString(), mime, System.currentTimeMillis()))
            }
            setStatus(
                if (files.size == 1) "Saved ✔  Downloads/TubeGrab/${files[0].name}"
                else "Saved ✔  ${files.size} files to Downloads/TubeGrab"
            )
        } catch (e: Exception) {
            setStatus(if (cancelRequested) "Cancelled." else friendlyError(e.message.orEmpty()))
        } finally {
            workDir.deleteRecursively()
        }
    }

    private fun friendlyError(msg: String): String {
        val m = msg.lowercase()
        return when {
            "sign in to confirm" in m && "bot" in m ->
                "YouTube blocked this request. Tap “Update engine” and try again."
            "login required" in m || "log in" in m || "logged-in" in m || "cookies" in m ||
                "requested content is not available" in m || "private" in m ->
                "This video needs you to be signed in. Tap “Sign in to sites”, sign in, then try again."
            "drm" in m -> "This video is DRM-protected, so it can't be downloaded."
            "unsupported url" in m ->
                "No video found at that link. Open the page in the built-in browser, play the video, then tap Download there."
            else -> "Failed: " + msg.lines().lastOrNull { it.isNotBlank() }.orEmpty().take(300) +
                "\n\nTip: tap “Update engine” — sites change often and break old versions."
        }
    }

    private fun mimeFor(f: File, mode: Mode): String = when (f.extension.lowercase()) {
        "mp4", "m4v" -> "video/mp4"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "webm" -> if (mode == Mode.MP3) "audio/webm" else "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        "opus", "ogg" -> "audio/ogg"
        else -> "application/octet-stream"
    }

    private suspend fun saveToDownloads(src: File, mode: Mode): Pair<Uri, String> = withContext(Dispatchers.IO) {
        val resolver = app.contentResolver
        val mime = mimeFor(src, mode)
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, src.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/TubeGrab")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Couldn't create file in Downloads.")
        resolver.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        uri to mime
    }
}
