package com.steven.tubegrab

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.steven.tubegrab.databinding.ActivityBrowserBinding
import kotlinx.coroutines.launch
import org.json.JSONArray

/** Built-in browser: watches what each page loads and offers any video/audio it finds. */
class BrowserActivity : AppCompatActivity() {

    private lateinit var b: ActivityBrowserBinding
    private val found = LinkedHashMap<String, String>()   // media url -> kind (main thread only)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pageUrl = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityBrowserBinding.inflate(layoutInflater)
        setContentView(b.root)

        val start = intent.getStringExtra(EXTRA_URL) ?: HOME
        intent.getStringExtra(EXTRA_SIGNIN)?.let { site ->
            b.banner.visibility = View.VISIBLE
            b.banner.text = "Sign in to $site below, then tap ✕ to go back. Your login stays on this phone " +
                "and is only used to download videos your account can already see."
        }

        val wv = b.webView
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            userAgentString = Web.userAgent(this@BrowserActivity)
        }
        Downloader.browserUserAgent = wv.settings.userAgentString

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Stay in the browser; block "open in app" links like instagram:// or intent://
                val scheme = request.url.scheme?.lowercase()
                return scheme != "http" && scheme != "https"
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                pageUrl = url
                if (!b.urlField.hasFocus()) b.urlField.setText(url)
                found.clear()
                updateFab()
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                pageUrl = url
                if (!b.urlField.hasFocus()) b.urlField.setText(url)
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url.toString()
                MediaSniffer.classify(u)?.let { kind ->
                    val clean = MediaSniffer.clean(u)
                    mainHandler.post { addFound(clean, kind) }
                }
                return null // never modify the page, just watch
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                b.pageProgress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
                b.pageProgress.progress = newProgress
            }
        }

        b.urlField.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { go(v.text.toString()); true } else false
        }
        b.closeButton.setOnClickListener { finish() }
        b.fab.setOnClickListener { scanAndShow() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (b.webView.canGoBack()) b.webView.goBack() else finish()
            }
        })

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Downloader.state.collect { s ->
                    val active = s.busy || s.queued > 0
                    b.dlStatus.visibility = if (active) View.VISIBLE else View.GONE
                    b.dlStatus.text = s.status + if (s.queued > 0) " · ${s.queued} queued" else ""
                }
            }
        }

        if (savedInstanceState == null) wv.loadUrl(start) else wv.restoreState(savedInstanceState)
        updateFab()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        b.webView.saveState(outState)
    }

    override fun onDestroy() {
        b.webView.destroy()
        super.onDestroy()
    }

    private fun go(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains('.') && !t.contains(' ') -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        b.webView.loadUrl(url)
        b.urlField.clearFocus()
        b.webView.requestFocus()
        getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(b.urlField.windowToken, 0)
    }

    private fun addFound(url: String, kind: String) {
        if (found.containsKey(url)) return
        if (found.size >= 40) found.remove(found.keys.first())
        found[url] = kind
        updateFab()
    }

    private fun updateFab() {
        b.fab.text = if (found.isEmpty()) "Download" else "Download (${found.size} found)"
    }

    private fun scanAndShow() {
        b.webView.evaluateJavascript(JS_SCAN) { result ->
            try {
                val arr = JSONArray(result ?: "[]")
                for (i in 0 until arr.length()) {
                    val u = arr.optString(i)
                    if (u.startsWith("http")) addFound(MediaSniffer.clean(u), MediaSniffer.classify(u) ?: "Video on page")
                }
            } catch (e: Exception) { /* page returned nothing usable */ }
            showChoices()
        }
    }

    private fun showChoices() {
        val page = pageUrl.ifEmpty { b.webView.url ?: return }
        if (!page.startsWith("http")) return
        val site = Sites.label(Sites.host(page))
        val entries = mutableListOf<Pair<String, String?>>()   // label to media url (null = whole page)
        entries += "★ This page — smart mode ($site, recommended)" to null
        found.entries.reversed().forEach { (u, kind) -> entries += "$kind · ${MediaSniffer.shortName(u)}" to u }

        MaterialAlertDialogBuilder(this)
            .setTitle(if (found.isEmpty()) "Download from this page" else "Found ${found.size} media link(s)")
            .setItems(entries.map { it.first }.toTypedArray()) { _, i -> pickFormat(page, entries[i].second) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickFormat(page: String, media: String?) {
        val opts = arrayOf("Video · MP4 · best", "Video · MP4 · 720p", "Audio · MP3 · 320 kbps", "Audio · MP3 · 128 kbps")
        MaterialAlertDialogBuilder(this)
            .setTitle("Save as")
            .setItems(opts) { _, i ->
                val (mode, q) = when (i) {
                    0 -> Mode.MP4 to 0
                    1 -> Mode.MP4 to 720
                    2 -> Mode.MP3 to 320
                    else -> Mode.MP3 to 128
                }
                val job = if (media == null) {
                    DownloadJob(page, mode, q, cookieHosts = listOf(Sites.host(page)))
                } else {
                    DownloadJob(media, mode, q, referer = page, cookieHosts = listOf(Sites.host(page), Sites.host(media)))
                }
                Downloader.enqueue(this, job)
                Toast.makeText(this, "Added to downloads", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_SIGNIN = "signin"
        private const val HOME = "https://www.google.com"

        private const val JS_SCAN = """(function(){var o=[];document.querySelectorAll('video,video source,audio,audio source').forEach(function(v){var u=v.currentSrc||v.src;if(u&&u.indexOf('http')===0)o.push(u)});return o;})()"""
    }
}
