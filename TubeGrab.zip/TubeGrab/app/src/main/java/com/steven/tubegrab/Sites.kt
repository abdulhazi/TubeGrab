package com.steven.tubegrab

import android.content.Context
import android.net.Uri
import android.webkit.WebSettings

/** A site with special handling (badge colour, sign-in page, session cookie name). */
data class Site(
    val name: String,
    val badge: String,
    val color: Int,
    val loginUrl: String?,
    val baseDomain: String,
    val sessionCookie: String?,
)

object Sites {
    val known = listOf(
        Site("YouTube", "YT", 0xFFE53935.toInt(), null, "youtube.com", null),
        Site("Instagram", "IG", 0xFFC13584.toInt(), "https://www.instagram.com/accounts/login/", "instagram.com", "sessionid"),
        Site("Facebook", "FB", 0xFF1877F2.toInt(), "https://m.facebook.com/login/", "facebook.com", "c_user"),
        Site("TikTok", "TT", 0xFF222222.toInt(), "https://www.tiktok.com/login", "tiktok.com", "sessionid"),
        Site("X (Twitter)", "X", 0xFF444444.toInt(), "https://x.com/i/flow/login", "x.com", "auth_token"),
    )

    private val aliases = mapOf(
        "youtu.be" to "youtube.com",
        "twitter.com" to "x.com",
        "fb.watch" to "facebook.com",
        "fb.com" to "facebook.com",
    )

    private val secondLevel = setOf("co", "com", "ac", "or", "go", "net", "org", "gov", "edu", "web", "my", "sch")

    fun host(url: String): String = try {
        Uri.parse(url).host?.lowercase()?.removePrefix("www.") ?: ""
    } catch (e: Exception) { "" }

    /** "m.facebook.com" -> "facebook.com", "news.detik.co.id" -> "detik.co.id" */
    fun baseDomain(host: String): String {
        val h = host.lowercase().removePrefix("www.")
        aliases.entries.firstOrNull { h == it.key || h.endsWith("." + it.key) }?.let { return it.value }
        val parts = h.split('.').filter { it.isNotEmpty() }
        if (parts.size <= 2) return h
        val sld = parts[parts.size - 2]
        val tld = parts.last()
        return if (tld.length == 2 && sld in secondLevel) parts.takeLast(3).joinToString(".")
        else parts.takeLast(2).joinToString(".")
    }

    fun forHost(host: String): Site? {
        val b = baseDomain(host)
        return known.firstOrNull { it.baseDomain == b }
    }

    fun label(host: String): String = forHost(host)?.name ?: baseDomain(host).ifEmpty { "Web" }

    fun badge(host: String): String =
        forHost(host)?.badge ?: (baseDomain(host).firstOrNull()?.uppercase() ?: "?")

    fun color(host: String): Int = forHost(host)?.color ?: run {
        val palette = intArrayOf(
            0xFF00897B.toInt(), 0xFF5E35B1.toInt(), 0xFFF4511E.toInt(),
            0xFF3949AB.toInt(), 0xFF6D4C41.toInt(), 0xFF43A047.toInt(),
        )
        palette[(baseDomain(host).hashCode() and 0x7fffffff) % palette.size]
    }
}

object Web {
    /** Normal mobile Chrome user agent (without the WebView "wv" marker some sites block). */
    fun userAgent(ctx: Context): String =
        WebSettings.getDefaultUserAgent(ctx)
            .replace("; wv", "")
            .replace(Regex("""Version/\d+(\.\d+)* """), "")
}
