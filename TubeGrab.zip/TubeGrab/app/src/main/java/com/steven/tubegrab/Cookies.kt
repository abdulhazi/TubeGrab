package com.steven.tubegrab

import android.webkit.CookieManager
import java.io.File

/**
 * Logins happen inside the app's own browser. Its cookies are handed to yt-dlp
 * (as a cookies.txt file) so it can download videos only visible when signed in.
 * Nothing leaves the phone.
 */
object Cookies {

    fun isSignedIn(site: Site): Boolean {
        val name = site.sessionCookie ?: return false
        val raw = CookieManager.getInstance().getCookie("https://www.${site.baseDomain}") ?: return false
        return raw.split(";").map { it.trim() }.any { it.startsWith("$name=") && it.length > name.length + 1 }
    }

    fun signOutAll(done: () -> Unit) {
        CookieManager.getInstance().removeAllCookies {
            CookieManager.getInstance().flush()
            done()
        }
    }

    /** Writes a Netscape cookies.txt. Call on the main thread. Returns null if there are no cookies. */
    fun export(file: File, hosts: Collection<String>): File? {
        val cm = CookieManager.getInstance()
        cm.flush()
        val domains = (hosts.map { Sites.baseDomain(it) } + Sites.known.map { it.baseDomain })
            .filter { it.isNotBlank() }
            .toSet()
        val expiry = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val seen = HashSet<String>()
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        var count = 0
        for (d in domains) {
            for (prefix in listOf("https://www.", "https://", "https://m.")) {
                val raw = cm.getCookie(prefix + d) ?: continue
                for (part in raw.split(";")) {
                    val p = part.trim()
                    val eq = p.indexOf('=')
                    if (eq <= 0) continue
                    val name = p.substring(0, eq)
                    val value = p.substring(eq + 1)
                    if (name.contains('\t') || value.contains('\t')) continue
                    if (!seen.add("$d|$name")) continue
                    sb.append(".$d\tTRUE\t/\tTRUE\t$expiry\t$name\t$value\n")
                    count++
                }
            }
        }
        if (count == 0) {
            file.delete()
            return null
        }
        file.writeText(sb.toString())
        return file
    }
}
