package com.steven.tubegrab

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(
    val name: String,
    val host: String,
    val mode: String,
    val uri: String,
    val mime: String,
    val time: Long,
)

object History {
    private lateinit var prefs: SharedPreferences
    private val _items = MutableStateFlow<List<HistoryEntry>>(emptyList())
    val items: StateFlow<List<HistoryEntry>> = _items.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("history", Context.MODE_PRIVATE)
        _items.value = load()
    }

    @Synchronized
    fun add(e: HistoryEntry) {
        val list = (listOf(e) + _items.value).take(100)
        save(list)
        _items.value = list
    }

    @Synchronized
    fun clear() {
        save(emptyList())
        _items.value = emptyList()
    }

    private fun load(): List<HistoryEntry> = try {
        val arr = JSONArray(prefs.getString("items", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            HistoryEntry(
                o.getString("name"), o.optString("host"), o.optString("mode"),
                o.getString("uri"), o.optString("mime", "*/*"), o.optLong("time"),
            )
        }
    } catch (e: Exception) { emptyList() }

    private fun save(list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("name", it.name).put("host", it.host).put("mode", it.mode)
                    .put("uri", it.uri).put("mime", it.mime).put("time", it.time)
            )
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
