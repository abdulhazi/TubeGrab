package com.steven.tubegrab

import android.app.Application
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Mode { MP4, MP3 }

data class UiState(
    val busy: Boolean = false,
    val progress: Int = -1,          // -1 = indeterminate
    val status: String = "Paste a YouTube link to start.",
    val lastSaved: String? = null,
)

class DownloadViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private var job: Job? = null
    private val processId = "tubegrab-download"

    /** quality: video height (e.g. 1080) for MP4, or bitrate in kbps (e.g. 320) for MP3. 0 = best. */
    fun download(url: String, mode: Mode, quality: Int) {
        if (_state.value.busy) return
        if (!App.initOk) {
            _state.value = UiState(status = "Engine failed to start: ${App.initError}")
            return
        }
        job = viewModelScope.launch(Dispatchers.IO) {
            val workDir = File(getApplication<Application>().cacheDir, "dl").apply {
                deleteRecursively(); mkdirs()
            }
            try {
                _state.value = UiState(busy = true, status = "Fetching video info…")

                val request = YoutubeDLRequest(url.trim()).apply {
                    addOption("--no-playlist")
                    addOption("--no-mtime")
                    addOption("-o", "${workDir.absolutePath}/%(title).120B.%(ext)s")
                    when (mode) {
                        Mode.MP4 -> {
                            val h = if (quality > 0) "[height<=$quality]" else ""
                            addOption(
                                "-f",
                                "bv*$h[ext=mp4]+ba[ext=m4a]/b$h[ext=mp4]/bv*$h+ba/b$h/b"
                            )
                            addOption("--merge-output-format", "mp4")
                        }
                        Mode.MP3 -> {
                            addOption("-f", "ba/b")
                            addOption("-x")
                            addOption("--audio-format", "mp3")
                            addOption("--audio-quality", if (quality > 0) "${quality}K" else "0")
                        }
                    }
                }

                YoutubeDL.getInstance().execute(request, processId) { progress, eta, _ ->
                    val pct = progress.toInt()
                    _state.value = _state.value.copy(
                        progress = if (pct in 0..100) pct else -1,
                        status = if (pct >= 100) "Converting…"
                        else if (pct >= 0) "Downloading… $pct%  (about ${eta}s left)"
                        else "Working…"
                    )
                }

                _state.value = _state.value.copy(progress = -1, status = "Saving to Downloads…")
                val wanted = if (mode == Mode.MP4) "mp4" else "mp3"
                val file = workDir.listFiles()
                    ?.filter { it.isFile && it.extension.equals(wanted, true) }
                    ?.maxByOrNull { it.length() }
                    ?: workDir.listFiles()?.filter { it.isFile }?.maxByOrNull { it.length() }
                    ?: error("Download finished but no file was produced.")

                val savedName = saveToDownloads(file, mode)
                _state.value = UiState(status = "Saved ✔  Downloads/TubeGrab/$savedName", lastSaved = savedName)
            } catch (e: Exception) {
                val msg = e.message.orEmpty()
                _state.value = UiState(
                    status = when {
                        job?.isCancelled == true -> "Cancelled."
                        msg.contains("Sign in to confirm", true) ->
                            "YouTube blocked this request. Tap “Update engine” and try again."
                        msg.contains("Unsupported URL", true) -> "That link isn't supported."
                        else -> "Failed: " + msg.lines().lastOrNull { it.isNotBlank() }.orEmpty().take(300) +
                            "\n\nTip: tap “Update engine” — YouTube changes often break old versions."
                    }
                )
            } finally {
                workDir.deleteRecursively()
            }
        }
    }

    fun cancel() {
        YoutubeDL.getInstance().destroyProcessById(processId)
        job?.cancel()
        _state.value = UiState(status = "Cancelled.")
    }

    fun updateEngine() {
        if (_state.value.busy) return
        viewModelScope.launch(Dispatchers.IO) {
            _state.value = UiState(busy = true, status = "Updating yt-dlp engine…")
            _state.value = try {
                val result = YoutubeDL.getInstance()
                    .updateYoutubeDL(getApplication(), YoutubeDL.UpdateChannel.STABLE)
                val version = YoutubeDL.getInstance().version(getApplication()) ?: "?"
                UiState(
                    status = if (result == YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE)
                        "Engine already up to date ($version)."
                    else "Engine updated to $version ✔"
                )
            } catch (e: Exception) {
                UiState(status = "Update failed: ${e.message?.take(200)}")
            }
        }
    }

    private suspend fun saveToDownloads(src: File, mode: Mode): String = withContext(Dispatchers.IO) {
        val resolver = getApplication<Application>().contentResolver
        val mime = when (src.extension.lowercase()) {
            "mp4" -> "video/mp4"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "webm" -> if (mode == Mode.MP3) "audio/webm" else "video/webm"
            else -> "application/octet-stream"
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, src.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/TubeGrab")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Couldn't create file in Downloads.")
        resolver.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        src.name
    }
}
