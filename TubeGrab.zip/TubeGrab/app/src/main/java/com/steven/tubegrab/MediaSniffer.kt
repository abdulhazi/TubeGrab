package com.steven.tubegrab

import android.net.Uri

/** Spots video/audio files and streams among the requests a web page makes. */
object MediaSniffer {

    private val videoExt = listOf(".mp4", ".m4v", ".mov", ".webm", ".mkv")
    private val audioExt = listOf(".mp3", ".m4a", ".aac", ".ogg", ".opus")
    private val dropParams = setOf("bytestart", "byteend", "range")

    fun classify(url: String): String? {
        val l = url.lowercase()
        if (!l.startsWith("http")) return null
        val uri = try { Uri.parse(url) } catch (e: Exception) { return null }
        val host = uri.host?.lowercase() ?: return null
        if (host.contains("googlevideo.com")) return null // YouTube chunks — use smart mode instead
        val path = (uri.path ?: "").lowercase()
        return when {
            path.endsWith(".m3u8") -> "Stream (HLS)"
            path.endsWith(".mpd") -> "Stream (DASH)"
            videoExt.any { path.endsWith(it) } -> "Video file"
            audioExt.any { path.endsWith(it) } -> "Audio file"
            else -> null
        }
    }

    /** Removes byte-range parameters so the whole file downloads, not a slice. */
    fun clean(url: String): String = try {
        val uri = Uri.parse(url)
        val names = uri.queryParameterNames
        if (names.none { it.lowercase() in dropParams }) url
        else {
            val b = uri.buildUpon().clearQuery()
            names.filter { it.lowercase() !in dropParams }.forEach { n ->
                uri.getQueryParameters(n).forEach { v -> b.appendQueryParameter(n, v) }
            }
            b.build().toString()
        }
    } catch (e: Exception) { url }

    fun shortName(url: String): String = try {
        val uri = Uri.parse(url)
        val host = uri.host?.removePrefix("www.") ?: ""
        val last = uri.lastPathSegment?.take(40) ?: ""
        "$host/…/$last"
    } catch (e: Exception) { url.take(60) }
}
